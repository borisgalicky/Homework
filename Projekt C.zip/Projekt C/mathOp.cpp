#include "mathOp.h""
float calcRectangleSquare(float a,float b)
{
return a*b;
}
