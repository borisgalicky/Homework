/*
@Author: Boris Galick�, 1.N
@Date: 29-11-2017
@Parameters: a,b
@Result: Knowledge of
@Decscription: My first project in C++
*/
float calcRectangleSquare(float a,float b);
float calcRectangleDiagonal(float a,float b);
