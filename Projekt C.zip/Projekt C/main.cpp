#include <iostream>
#include <cmath>
#include "mathOp.h"
using namespace std;
int main(int argc, char** argv)
{
float a,b,c;
cout << "Insert height of rectangle: ";
cin >> a;
cout << "Insert width of rectangle: ";
cin >> b;
cout << "Rectangle square is " << calcRectangleSquare(a,b);
(c*c)=(a*a)+(b*b);
c=sqrt(c);
cout << "Rectangle diagonal is " c;
return 0;
}
